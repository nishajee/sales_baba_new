<?php

namespace App\Http\Controllers\Api_Controller;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Userdetail_api;
use Validator;
use Auth;

class UsersController extends Controller
{
   function users()
   {
      $user_details= Userdetail_api::where('users_role', 3)->where('org_id',Auth::user()->org_id)->paginate(20);
      foreach($user_details as $key_user =>$value_user)
      {
          $user_details[$key_user]->profile_img="https://baba.software/saletelecaller_api/public/images/user_profile/".$value_user->profile_img ?? "";
      }
      return response()->json($user_details, 200);
      // return response()->json(Userdetail_api::get(),200);
   }
   function list_sales_people()
   {
      $user_details= Userdetail_api::where('users_role', 3)->where('org_id',Auth::user()->org_id)->orderBy('id','DESC')->get();
      foreach($user_details as $key_user =>$value_user)
      {
          $user_details[$key_user]->profile_img="https://baba.software/saletelecaller_api/public/images/user_profile/".$value_user->profile_img ?? "";
      }
      return response()->json($user_details, 200);
      // return response()->json(Userdetail_api::get(),200);
   }
   public function usersById($id)
   {
       $user_details=Userdetail_api::find($id);
       if($user_details->profile_img!="")
       {
       $user_details->profile_img="https://baba.software/saletelecaller_api/public/images/user_profile/".$user_details->profile_img ?? "";
       }else
       {
           $user_details->profile_img="";
       }
      return response()->json($user_details, 200); //200 is response code
   }

   public function usersSave(Request $request,$user_id="") //now we can create object
   {
       $imageName="";
       if (@$request->file('profile_img') != '') {
         request()->validate([
             'profile_img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
         ]);
         $imageName = time() . '.' . request()->profile_img->getClientOriginalExtension();
         request()->profile_img->move(public_path('images/profile_pic'), $imageName);
     }
      if($user_id!="")
      {
         $users =Userdetail_api::find($request->user_id);
         $validator = Validator::make($request->all(), [
              'username' => 'required|string',
              'email' => 'required|string|email|max:100',
              'password' => 'required',
              'phone' => 'required',
              'designation' => 'required',
              'gender' => 'required',
              'pincode' => 'required',
              'address' => 'required',
          ]);
          $message="Sales People Edited";
      }else
      {
         $users =new Userdetail_api();
         $validator = Validator::make($request->all(), [
              'username' => 'required|string|unique:users',
              'email' => 'required|string|email|max:100|unique:users',
              'password' => 'required',
              'phone' => 'required',
              'designation' => 'required',
              'gender' => 'required',
              'pincode' => 'required',
              'address' => 'required',
          ]);
          $message="Sales People Added";
      }
        if($validator->fails()){
            return response()->json(['message'=>$validator->errors()->toJson(),'status'=>false], 200);
        }
      $users->users_role=3;
      $users->org_id=Auth::user()->org_id;
      $users->users_type=2;
      $users->username=$request->username;
      $users->name=$request->name;
      $users->password=$request->password;
      $users->email=$request->email;
      $users->phone=$request->phone;
      $users->designation=$request->designation;
      $users->gender=$request->gender;
      if($imageName!="")
      {
      $users->profile_img=$imageName;
      }
      $users->city=$request->city;
      $users->state=$request->state;
      $users->address=$request->address;
      $users->address2=$request->address2;
      $users->pincode=$request->pincode;
      $users->country=$request->country;
      $users->status=1;
      $users->save();
      return response()->json(['data'=>$users,'status'=>true,'message'=>$message], 200); //200 is response code
   }
   public function usersUpdate(Request $request, Userdetail_api $users)
   {
      $users->update($request->all());
      return response()->json(['data'=>$users,'status'=>true], 200);
   }
   public function usersDelete(Request $request, Userdetail_api $users)
   {
      $users->delete();
      return response()->json(null, 204);
   }
}
