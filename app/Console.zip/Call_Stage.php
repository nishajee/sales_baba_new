<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Call_Stage extends Model
{
    public $timestamps = false;
    public  $table = "callstage";
}
