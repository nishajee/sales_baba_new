<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lead_status extends Model
{
    public $timestamps = false;
    public $table='lead_status';
    
}
