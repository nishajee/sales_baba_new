<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Countries extends Model
{
    protected $primaryKey = 'id';
	protected $table = 'countries';
}
