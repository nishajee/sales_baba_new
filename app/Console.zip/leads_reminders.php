<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class leads_reminders extends Model
{
    //
}
