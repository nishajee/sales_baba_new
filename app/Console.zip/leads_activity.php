<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class leads_activity extends Model
{
    public $timestamp=false;
    public $table='leads_activity';
}
